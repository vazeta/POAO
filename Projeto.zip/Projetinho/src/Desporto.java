import java.io.Serializable;
import java.util.ArrayList;
/**
 * Classe responsável pelas perguntas relacionadas a Desporto
 */
public class Desporto extends Pergunta implements Serializable {
    private int pontuacaoDesporto;
    private int majDesporto;

    /**
     * Construtor que inicializa pergunta,opcoes e majoração de ciências igual a 3
     * @param pergunta pergunta
     * @param opcoes opções
     * @param resposta resposta
     */
    public Desporto(String pergunta, String opcoes, String resposta){
        super(pergunta, opcoes, resposta);
        this.majDesporto=3;
    }
    /**
     * Método de acesso a pontuação de desporto
     * @return pontuação de desporto
     */
    public int getPontuacaoDesporto() {
        return pontuacaoDesporto;
    }

    /**
     * Método para alterar pontuação de desporto
     * @param pontuacaoDesporto pontuação de desporto
     */
    public void setPontuacaoDesporto(int pontuacaoDesporto) {
        this.pontuacaoDesporto = pontuacaoDesporto;
    }
    /**
     * Método de acesso a majoração de desporto
     * @return majoração de desporto
     */
    public int getMajDesporto() {
        return majDesporto;
    }
    /**
     * Método toString() resonsável por imprimir tipo de pergunta, pontuação, pergunta, opções e resposta
     * @return Tipo de pergunta, pontuação, pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return super.toString();
    }
    /**
     * Método responsável por atribuir pontuação às perguntas de Desporto
     * @return Pontuação de Desporto
     */
    @Override
    protected int atribuiPontuacao() {
        setPontuacaoDesporto(getPontuacao()+getMajDesporto());
        return getPontuacaoDesporto();
    }
    /**
     * Método responsável por selecionar as opções que irão aparecer ao jogador
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções
     */
    protected String selecionaOpcoes(ArrayList<Pergunta> perguntas) {
        String opcoesSelecionadas=null;
        opcoesSelecionadas=getOpcoes();
        return opcoesSelecionadas;
    }
}



