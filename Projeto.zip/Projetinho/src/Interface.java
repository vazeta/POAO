import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.Serializable;
/**
 * Classe responsável pela interface
 */
public class Interface extends JFrame implements Serializable{
    private ArrayList<Pergunta> perguntas;
    private String nomeJogador;
    private ArrayList<Object> perguntasCertas;
    private ArrayList<Object> perguntasErradas;
    private int pontuacaoTotal;
    String timestamp;
    private static final String FORMATO_DATA_HORA = "yyyyMMddHHmmss";

    /**
     * Construtor responsável por inicializar atributos e executa alguns métodos para exibir perguntas, verificar pontuações e exibir o ranking.
     * @param perguntas ArrayList que contém todas as perguntas
     */
    public Interface(ArrayList<Pergunta> perguntas) {
        super("POOTrivia");
        this.perguntas = perguntas;
        this.perguntasCertas = new ArrayList<>();
        this.perguntasErradas = new ArrayList<>();
        Date dataHoraAtual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat(FORMATO_DATA_HORA);
        this.timestamp = formato.format(dataHoraAtual);
        exibirPerguntas();
        if(melhoraPontuacao()){
            Ficheiro.removePasta(Ficheiro.fazerIniciais(getNomeJogador()));
            String nomeArquivo = Ficheiro.guardarEstadoJogo(this);
            Ficheiro.introduzirPasta(nomeArquivo);
        }
        else if(verificaExistencia()){
            String nomeArquivo = Ficheiro.guardarEstadoJogo(this);
            Ficheiro.introduzirPasta(nomeArquivo);
        }
        Ficheiro.rank("FicheirosObjetos");
        exibirRank();
    }
    /**
     * Método de acesso ao timeStamp
     * @return timeStamp
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * Método par alterar o timeStamp
     * @param timestamp timeStamp
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    /**
     * Método de acesso ao nome do jogador
     * @return nome do jogador
     */
    public String getNomeJogador() {
        return nomeJogador;
    }
    /**
     * Método para alterar o nome do jogador
     * @param nomeJogador nome do jogador
     */
    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }
    /**
     * Método para acessar a ArraList de perguntas certas
     * @return ArraList de perguntas certas
     */
    public ArrayList<Object> getPerguntasCertas() {
        return perguntasCertas;
    }
    /**
     * Método para alterar a ArraList de perguntas certas
     * @param perguntasCertas ArraList de perguntas certas
     */
    public void setPerguntasCertas(ArrayList<Object> perguntasCertas) {
        this.perguntasCertas = perguntasCertas;
    }
    /**
     * Método para acessar a ArraList de perguntas erradas
     * @return ArraList de perguntas erradas
     */
    public ArrayList<Object> getPerguntasErradas() {
        return perguntasErradas;
    }
    /**
     * Método para alterar a ArraList de perguntas erradas
     * @param perguntasErradas ArraList de perguntas erradas
     */
    public void setPerguntasErradas(ArrayList<Object> perguntasErradas) {
        this.perguntasErradas = perguntasErradas;
    }
    /**
     * Método para acessar a pontuação total
     * @return pontuação total
     */
    public int getPontuacaoTotal() {
        return pontuacaoTotal;
    }
    /**
     * Método para alterar a pontuação tootal
     * @param pontuacaoTotal pontuação total
     */
    public void setPontuacaoTotal(int pontuacaoTotal) {
        this.pontuacaoTotal = pontuacaoTotal;
    }
    /**
     * Método responsável por exibir as perguntas e as respetivas opções na nossa janela
     */
    private void exibirPerguntas() {
        int primeiraOpcao = -3;
        int segundaOpcao = -2;
        int count = 0;
        for (Pergunta pergunta : perguntas) {
            String[] opcoes = pergunta.selecionaOpcoes(perguntas).split(";");
            while(primeiraOpcao != segundaOpcao) {
                int respostaIndex = JOptionPane.showOptionDialog(
                        this,
                        pergunta.getPergunta(),
                        "POOTrivia",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        opcoes,
                        opcoes[0]
                );
                if(count%2 == 0){
                    primeiraOpcao = respostaIndex;
                }
                else{
                    segundaOpcao = respostaIndex;
                }
                if (respostaIndex != -1) {
                    String respostaEscolhida = opcoes[respostaIndex];
                    if (primeiraOpcao == segundaOpcao) {
                        if (respostaEscolhida.equals(pergunta.getResposta())) {
                            JOptionPane.showMessageDialog(this, "Resposta correta! Você ganhou " + pergunta.atribuiPontuacao() + " pontos!");
                            setPontuacaoTotal(getPontuacaoTotal() + pergunta.atribuiPontuacao());
                            perguntasCertas.add(pergunta.getPergunta());
                        } else {
                            JOptionPane.showMessageDialog(this, "Resposta incorreta.");
                            perguntasErradas.add(pergunta.getPergunta());
                        }
                    }
                }
                else {
                    JOptionPane.showMessageDialog(this, "Jogo encerrado. Você não respondeu todas as perguntas.");
                    this.setVisible(false);
                    System.exit(0);
                }
                count++;
            }
            primeiraOpcao = -3;
            segundaOpcao = -2;
            count = 0;
        }
        this.nomeJogador = JOptionPane.showInputDialog(this, "Qual é o seu nome completo?", "POOTrivia - Bem-vindo", JOptionPane.QUESTION_MESSAGE);
        while (nomeJogador == null || nomeJogador.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "É necessário introduzir o nome completo!");
            this.nomeJogador = JOptionPane.showInputDialog(this, "Qual é o seu nome completo?", "POOTrivia - Bem-vindo", JOptionPane.QUESTION_MESSAGE);
        }
        JOptionPane.showMessageDialog(this, "O Jogo acabou. Você obteve " + getPontuacaoTotal() + " pontos!");
        this.setVisible(false);
    }
    /**
     * Método responsável por exibir o top 3 do jogo e o jogador atual
     */
    private void exibirRank(){
        ArrayList<Interface> Objetos1 = Ficheiro.rank("FicheirosObjetos");
        StringBuilder mensagem = new StringBuilder("TOP 3:\n");
        int flag = 0;
        if(Objetos1.size() >= 3) {
            for (int i = 0 ; i < 3; i++) {
                mensagem.append(Objetos1.get(i).getNomeJogador()).append(" - ").append(Objetos1.get(i).getPontuacaoTotal()).append("\nData e Hora(yyyyMMddHHmmss):").append(Objetos1.get(i).getTimestamp()).append("\n");
                mensagem.append("---------------------------------------------\n");
                if(Objetos1.get(i).getNomeJogador().equals(nomeJogador)){
                    flag = 1;
                }

            }
        }
        else{
            for (int i = 0 ; i < Objetos1.size(); i++) {
                mensagem.append(Objetos1.get(i).getNomeJogador()).append(" - ").append(Objetos1.get(i).getPontuacaoTotal()).append("\nData e Hora(yyyyMMddHHmmss):").append(Objetos1.get(i).getTimestamp()).append("\n");
                mensagem.append("---------------------------------------------\n");
                if(Objetos1.get(i).getNomeJogador().equals(nomeJogador)){
                    flag = 1;
                }
            }
        }
        if(flag == 0){
            mensagem.append("TUA PONTUCAO").append(" - ").append(getPontuacaoTotal()).append("\nData e Hora(yyyyMMddHHmmss):").append(getTimestamp()).append("\n");
        }
        JOptionPane.showMessageDialog(this, mensagem.toString(), "POOTrivia - Lista de Pontuações", JOptionPane.INFORMATION_MESSAGE);
        this.setVisible(false);
    }
    /**
     * Método responsável por pergunatar ao jogador se quer repetir o jogo
     * @return escolha
     */
    private boolean repeteJogo(){
        int escolha = JOptionPane.showConfirmDialog(
                this,
                "Quer repetir o jogo?",
                "POOTrivia - Bem-vindo",
                JOptionPane.YES_NO_OPTION
        );
        return escolha == JOptionPane.YES_OPTION;
    }

    /**
     * Método responsável por verificar se a pontucao de um certo jogador foi maior
     * @return flag booleana
     */
    private boolean melhoraPontuacao(){
        ArrayList<Interface> Objetos2 = Ficheiro.rank("FicheirosObjetos");
        boolean flag = false;
        for(Interface objeto : Objetos2){
            if(objeto.getNomeJogador().equals(nomeJogador)){
                if(objeto.getPontuacaoTotal() < pontuacaoTotal){
                    flag = true;
                }
            }
        }
        return flag;
    }
    /**
     * Método responsável por verificar se ja existe um jogo do mesmo jogador(nome)
     * @return flag booleana
     */
    private boolean verificaExistencia(){
        ArrayList<Interface> Objetos2 = Ficheiro.rank("FicheirosObjetos");
        boolean flag = true;
        for(Interface objeto : Objetos2){
            if(objeto.getNomeJogador().equals(nomeJogador)){
                flag = false;
            }
        }
        return flag;
    }
    /**
     * Main da interface(Chama todas as outras funções)
     * @param args args
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Interface jogo;
            do {
                ArrayList<Pergunta> perguntas = new ArrayList<>();
                Ficheiro.leTexto(perguntas, "pootrivia.txt");
                Pergunta.selecionar(perguntas);
                jogo = new Interface(perguntas);
            } while (jogo.repeteJogo());
            System.exit(0);
        });
    }
}