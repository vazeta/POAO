import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.io.Serializable;
/**
 * Classe responsável pela manipulação e tratamento de ficheiros
 */
public class Ficheiro implements Serializable {
    /**
     * Método responsável por ler do ficheiro
     * @param perguntas ArrayList que contém todas as perguntas
     * @param nome nome do ficheiro
     */
    public static void leTexto(ArrayList<Pergunta> perguntas, String nome) {
        try {
            File f = new File(nome);
            FileReader leitor = new FileReader(f);
            BufferedReader linhas = new BufferedReader(leitor);
            String linha;
            while ((linha = linhas.readLine()) != null) {
                String[] separa = linha.split("-");
                int posicaoPergunta = (separa.length) - 5;
                int posicaoOpcoes = (separa.length) - 3;
                int resposta = (separa.length) - 1;
                String[] op = separa[posicaoOpcoes].split(";");
                String[] op2 = separa[posicaoOpcoes].split("\\|");
                String[] re = separa[resposta].split("\\|");
                if (separa.length == 7) {
                    if (linha.startsWith("Ciências") && (op.length <= 20 && op.length >= 10) && (separa[posicaoOpcoes].contains("|")) && (op2[0].contains(re[0]))&&(op2[1].contains(re[0]))) {
                        perguntas.add(new Ciencias(separa[posicaoPergunta], separa[posicaoOpcoes], separa[resposta]));
                    } else if (linha.startsWith("Artes") && (op.length <= 10 && op.length >= 5) && (separa[posicaoOpcoes].contains(separa[resposta]))) {
                        perguntas.add(new Artes(separa[posicaoPergunta], separa[posicaoOpcoes], separa[resposta]));
                    } else if (linha.startsWith("Futebol") && (op.length <= 20 && op.length >= 10) && (separa[posicaoOpcoes].contains("|")&& separa[resposta].contains("|"))&&(op2[0].contains(re[0]) || op2[1].contains(re[1]))) {
                        perguntas.add(new Futebol(separa[posicaoPergunta], separa[posicaoOpcoes], separa[resposta]));
                    } else if (linha.startsWith("Ski") && (op.length == 2) && (op[0].equals(separa[resposta]) || op[1].equals(separa[resposta]))) {
                        perguntas.add(new Ski(separa[posicaoPergunta], separa[posicaoOpcoes], separa[resposta]));
                    } else if (linha.startsWith("Natação") && (op.length == 2) && (op[0].equals(separa[resposta]) || op[1].equals(separa[resposta]))) {
                        perguntas.add(new Natacao(separa[posicaoPergunta], separa[posicaoOpcoes], separa[resposta]));
                    } else {
                        System.out.println("ERRO! FICHEIRO CORROMPIDO OU PERGUNTAS INTRODUZIDAS INDEVIDAMENTE!");
                        System.exit(0);
                    }
                } else {
                    System.out.println("ERRO! FICHEIRO CORROMPIDO OU PERGUNTAS INTRODUZIDAS INDEVIDAMENTE!");
                    System.exit(0);
                }
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Erro a abrir ficheiro.");
            System.exit(0);
        } catch (IOException ex) {
            System.out.println("Erro a ler ficheiro.");
            System.exit(0);
        }
    }

    /**
     * Método responsável por fazer as iniciais do nome do jogador
     *
     * @param nome nome do jogador
     * @return iniciais do nome
     */
    static String fazerIniciais(String nome) {
        String iniciais = String.valueOf(Character.toUpperCase(nome.charAt(0)));
        for (int i = 0; i < nome.length() - 1; i++) {
            if (nome.charAt(i) == ' ') {
                iniciais += Character.toUpperCase(nome.charAt(i + 1));
            }
        }
        return iniciais;
    }

    /**
     * Método responsável por criar os ficheiros de objetos
     *
     * @param interfaceJogo interface
     * @return nome do ficheiro de objetos
     */

    static String guardarEstadoJogo(Interface interfaceJogo) {
        String nomeArquivo;
        try {
            nomeArquivo = "pootrivia_jogo_" + interfaceJogo.getTimestamp() + "_" + fazerIniciais(interfaceJogo.getNomeJogador()) + ".dat";
            try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
                outputStream.writeObject(interfaceJogo);
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return nomeArquivo;
    }
    /**
     * Método responsável por introduzir um ficheiro de objetos numa pasta
     * @param nomeArquivo nome do ficheiro de objetos
     */
    public static void introduzirPasta(String nomeArquivo) {
        File pasta = new File("FicheirosObjetos");
        if (!pasta.exists()) {
            pasta.mkdir();
        }
        try {
            File destino = new File(pasta, nomeArquivo);
            Files.move(Paths.get(nomeArquivo), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Método responsável por remover um certo ficheiro da pasta
     * @param nomeArquivo nome
     */
    public static void removePasta(String nomeArquivo) {
        File pasta = new File("FicheirosObjetos");
        if (pasta.exists() && pasta.isDirectory()) {
            File[] arquivos = pasta.listFiles();
            for (File arquivo : arquivos) {
                if (arquivo.isFile() && arquivo.getName().contains(nomeArquivo)) {
                    arquivo.delete();
                }
            }
        }
    }

    /**
     * Método responsável por apresentar um rank dos jogos que ja se encontram na pasta
     * @param pasta nome da pasta
     * @return Array com os valores sorted
     */

    public static ArrayList<Interface> rank(String pasta) {
        ArrayList<Interface> Objetos = new ArrayList<>();
        File diretorio = new File(pasta);
        File[] arquivos = diretorio.listFiles();
        if (arquivos != null) {
            for (File arquivo : arquivos) {
                if (arquivo.isFile()) {
                    try {
                        FileInputStream fileInputStream = new FileInputStream(arquivo);
                        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

                        Interface objeto = (Interface) objectInputStream.readObject();

                        Objetos.add(objeto);

                        objectInputStream.close();
                        fileInputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        ArrayList<Interface> objetosOrdenados = new ArrayList<>(Objetos);
        objetosOrdenados.sort((o1, o2) -> Integer.compare(o2.getPontuacaoTotal(), o1.getPontuacaoTotal()));
        return objetosOrdenados;
    }
}