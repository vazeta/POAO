import java.io.Serializable;
import java.util.ArrayList;
/**
 * Classe responsável pelas perguntas relacionadas a Futebol
 */
public class Futebol extends Desporto implements Serializable {
    private int pontuacaoFutebol;
    private int majFutebol;
    /**
     * Construtor que inicializa pergunta,opcoes e majoração de futebol igual a 1
     * @param pergunta pergunta
     * @param opcoes   opções
     * @param resposta resposta
     */
    public Futebol(String pergunta, String opcoes, String resposta) {
        super(pergunta, opcoes, resposta);
        this.majFutebol = 1;
    }
    /**
     * Método de acesso a pontuação de futebol
     * @return pontuação de futebol
     */
    public int getPontuacaoFutebol() {
        return pontuacaoFutebol;
    }
    /**
     * Método para alterar pontuação de futebol
     * @param pontuacaoFutebol pontuação de futebol
     */
    public void setPontuacaoFutebol(int pontuacaoFutebol) {
        this.pontuacaoFutebol = pontuacaoFutebol;
    }
    /**
     * Método de acesso a majoração de futebol
     * @return majoração de futebol
     */
    public int getMajFutebol() {
        return majFutebol;
    }
    /**
     * Método para alterar majoração de futebol
     * @param majFutebol majoração de futebol
     */
    public void setMajFutebol(int majFutebol) {
        this.majFutebol = majFutebol;
    }
    /**
     * Método toString() resonsável por imprimir tipo de pergunta, pontuação, pergunta, opções e resposta
     * @return Tipo de pergunta, pontuação, pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return "Futebol->" + " Pontuaçao da pergunta:" + atribuiPontuacao() + super.toString();
    }

    /**
     * Método responsável por atribuir pontuação às perguntas de futebol
     * @return Pontuação de Futebol
     */
    @Override
    protected int atribuiPontuacao() {
        setPontuacaoFutebol(super.atribuiPontuacao() + getMajFutebol());
        return getPontuacaoFutebol();
    }

    /**
     * Método responsável por selecionar as opções que irão aparecer ao jogador, dependendo da posição em que a pergunta aparece
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções(String)
     */
    protected String selecionaOpcoes(ArrayList<Pergunta> perguntas) {
        String opcao1;
        String opcao2;
        String resposta1 ;
        String resposta2;
        String opcoesSelecionadas = null;
        String[] opcoes = (getOpcoes()).split("\\|");
        String[] respostas = (getResposta()).split("\\|");
        opcao1 = opcoes[0];
        opcao2 = opcoes[1];
        resposta1 = respostas[0];
        resposta2 = respostas[1];
        if ((perguntas.indexOf(this) + 1) < 3) {
            opcoesSelecionadas = opcao1;
            setResposta(resposta1);
        } else if ((perguntas.indexOf(this) + 1) >= 3) {
            opcoesSelecionadas = opcao2;
            setResposta(resposta2);
        }
        return opcoesSelecionadas;
    }
}