import java.io.Serializable;
import java.util.ArrayList;
/**
 * Classe responsável pelas perguntas relacionadas a Natação
 */
public class Natacao extends Desporto implements Serializable {

    private int pontuacaoNatacao;
    private int majNatacao;
    /**
     * Construtor que inicializa pergunta,opcoes e majoração de natação igual a 3
     * @param pergunta pergunta
     * @param opcoes opções
     * @param resposta resposta
     */
    public Natacao(String pergunta, String opcoes, String resposta){
        super(pergunta, opcoes, resposta);
        this.majNatacao=10;
    }

    /**
     * Método de acesso a majoração de natação
     * @return majoração de natação
     */
    public int getMajNatacao() {
        return majNatacao;
    }

    /**
     * Método de acesso a pontuação de natação
     * @return pontuação de natação
     */
    public int getPontuacaoNatacao(){
        return pontuacaoNatacao;
    }
    /**
     * Método para alterar pontuação de natação
     * @param pontuacaoNatacao pontuação de natação
     */
    public void setPontuacaoNatacao(int pontuacaoNatacao) {
        this.pontuacaoNatacao = pontuacaoNatacao;
    }

    /**
     * Método toString() resonsável por imprimir tipo de pergunta, pontuação, pergunta, opções e resposta
     * @return Tipo de pergunta, pontuação, pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return "Natação->" + " Pontuaçao da pergunta:" + atribuiPontuacao() + super.toString();
    }

    /**
     * Método responsável por atribuir pontuação às perguntas de Natação
     * @return Pontuação de Natação
     */
    @Override
    protected int atribuiPontuacao() {
        setPontuacaoNatacao(super.atribuiPontuacao()+getMajNatacao());
        return getPontuacaoNatacao();
    }
    /**
     * Método responsável por selecionar as opções que irão aparecer ao jogador, neste caso, não são alteradas
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções (String)
     */
    protected String selecionaOpcoes(ArrayList<Pergunta> perguntas) {
        String opcoesSelecionadas;
        opcoesSelecionadas=getOpcoes();
        return opcoesSelecionadas;
    }
}
