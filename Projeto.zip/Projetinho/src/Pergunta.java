import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/**
 * Classe responsável pelo tratamento de cada pergunta
 */
public abstract class Pergunta implements Serializable {
    private String pergunta;
    private String opcoes;
    private String resposta;
    private int pontuacao;

    /**
     * Construtor que inicializa pergunta,opcoes, resposta e pontuação igual a 5
     * @param pergunta pergunta
     * @param opcoes opções
     * @param resposta resposta
     */
    public Pergunta(String pergunta, String opcoes, String resposta) {
        this.pergunta = pergunta;
        this.opcoes = opcoes;
        this.resposta = resposta;
        this.pontuacao = 5;
    }

    /**
     * Método de acesso a pergunta
     * @return pergunta
     */
    public String getPergunta() {
        return pergunta;
    }

    /**
     * Método para alterar pergunta
     * @param pergunta pergunta
     */
    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }
    /**
     * Método de acesso a opções
     * @return opções
     */
    public String getOpcoes() {
        return opcoes;
    }

    /**
     * Método para alterar opções
     * @param opcoes opções
     */
    public void setOpcoes(String opcoes) {
        this.opcoes = opcoes;
    }

    /**
     * Método de acessoa a resposta
     * @return resposta
     */
    public String getResposta() {
        return resposta;
    }

    /**
     * Método para letrar resposta
     * @param resposta resposta
     */
    public void setResposta(String resposta) {
        this.resposta = resposta;
    }
    /**
     * Método de acessoa a pontuação
     * @return pontuação
     */
    public int getPontuacao() {
        return pontuacao;
    }

    /**
     * Método para alterar pontuação
     * @param pontuacao pontuação
     */
    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }

    /**
     * Método toString() para imprimir pergunta, opções e resposta
     * @return pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return " -> Pergunta: " + pergunta +
                ", Opções: " + opcoes +
                ", Resposta: " + resposta;
    }
    /**
     * Método abstrato usado nas restantes classes, para atribuir pontuação dependendo do tipo de pergunta
     * @return pontuação de cada pergunta
     */
    protected abstract int atribuiPontuacao();
    /**
     * Método abstrato usado nas restantes classes, para selecionar as opções dependendo do tipo de pergunta e da posição em que aparece
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções
     */
    protected abstract String selecionaOpcoes(ArrayList<Pergunta> perguntas);
    /**
     * Método responsável por selecionar 5 perguntas a apresentar ao utilizador
     * @param perguntas ArrayList que contém todas as perguntas
     */
    public static void selecionar(ArrayList<Pergunta> perguntas) {
        ArrayList<Integer> numerosRetirar = new ArrayList<>();
        Random random = new Random(System.currentTimeMillis());
        int numPerguntasDesejadas = 5;
        for (int i = 0; i < perguntas.size(); i++) {
            numerosRetirar.add(i);
        }
        Collections.shuffle(numerosRetirar, random);
        int j = 0;
        while(perguntas.size() > numPerguntasDesejadas) {
            int indice = numerosRetirar.get(j);
            if (perguntas.size() > indice) {
                perguntas.remove(indice);
            }
            j++;
        }
        Collections.shuffle(perguntas, random);
    }
}