/**
 * Classe central do nosso jogo
 */
public class POOTrivia {
    /**
     * Main, respónsavel por chamar a interface, que irá mostrar o jogo ao utilizador
     * @param args args
     */
    public static void main(String[] args) {
        Interface.main(args);
    }
}