import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
/**
 * Classe responsável pelas perguntas relacionadas a Artes
 */
public class Artes extends Pergunta implements Serializable {
    private int pontuacaoArtes;
    private int majArtes;
    /**
     * Construtor que inicializa pergunta,opcoes e majoração de artes igual a 10
     * @param pergunta pergunta
     * @param opcoes opções
     * @param resposta resposta
     */
    public Artes(String pergunta, String opcoes, String resposta) {
        super(pergunta, opcoes, resposta);
        this.majArtes = 10;
    }
    /**
     * Método de acesso a pontuação de artes
     * @return pontuação de artes
     */

    public int getPontuacaoArtes() {
        return pontuacaoArtes;
    }

    /**
     * Método para alterar pontuação de artes
     * @param pontuacaoArtes pontuação de artes
     */
    public void setPontuacaoArtes(int pontuacaoArtes) {
        this.pontuacaoArtes = pontuacaoArtes;
    }

    /**
     * Método de acesso a majoração de artes
     * @return majoração de artes
     */
    public int getMajArtes() {
        return majArtes;
    }
    /**
     * Método toString() resonsável por imprimir tipo de pergunta, pontuação, pergunta, opções e resposta
     * @return Tipo de pergunta, pontuação, pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return "Artes->" +
                " Pontuaçao da pergunta: " + atribuiPontuacao() +
                super.toString();
    }

    /**
     * Método responsável por atribuir pontuação às perguntas de Artes
     * @return Pontuação de Artes
     */
    @Override
    protected int atribuiPontuacao() {
        setPontuacaoArtes(getPontuacao() * getMajArtes());
        return getPontuacaoArtes();
    }

    /**
     * Método responsável por selecionar as opções que irão aparecer ao jogador, dependendo da posição em que a pergunta aparece
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções
     */

    protected String selecionaOpcoes(ArrayList<Pergunta> perguntas) {
        Random random = new Random();
        String opcao1;
        String opcao2;
        String opcao3;
        String opcoesSelecionadas = null;
        if ((perguntas.indexOf(this) + 1) < 3) {
            String[] opcoes = (getOpcoes()).split(";");
            int indexOpcao1 = random.nextInt(opcoes.length);
            while (opcoes[indexOpcao1].equals(getResposta())) {
                indexOpcao1 = random.nextInt(opcoes.length);
            }
            opcao1 = opcoes[indexOpcao1];
            int indexOpcao2 = random.nextInt(opcoes.length);
            while (opcoes[indexOpcao2].equals(opcao1) || opcoes[indexOpcao2].equals(getResposta())) {
                indexOpcao2 = random.nextInt(opcoes.length);
            }
            opcao2 = opcoes[indexOpcao2];
            opcao3 = getResposta();
            opcoesSelecionadas = opcao1 + ";" + opcao2 + ";" + opcao3;
        } else if ((perguntas.indexOf(this) + 1) >= 3) {
            opcoesSelecionadas = getOpcoes();
        }
        return opcoesSelecionadas;
    }
}