import java.io.Serializable;
import java.util.ArrayList;
/**
 * Classe responsável pelas perguntas relacionadas a Ciências
 */
public class Ciencias extends Pergunta implements Serializable {

    private int pontuacaoCiencias;
    private int majCiencias;

    /**
     * Construtor que inicializa pergunta,opcoes e majoração de ciências igual a 5
     * @param pergunta pergunta
     * @param opcoes opções
     * @param resposta resposta
     */
    public Ciencias(String pergunta, String opcoes, String resposta){
        super(pergunta, opcoes, resposta);
        this.majCiencias=5;
    }

    /**
     * Método de acesso à pontuação de ciências
     * @return pontuação de ciências
     */
    public int getPontuacaoCiencias() {
        return pontuacaoCiencias;
    }

    /**
     * Método para alterar pontuação de ciências
     * @param pontuacaoCiencias pontuação de ciências
     */
    public void setPontuacaoCiencias(int pontuacaoCiencias) {
        this.pontuacaoCiencias = pontuacaoCiencias;
    }

    /**
     * Método de acesso a Majoração de Ciências
     * @return Majoração de Ciências
     */
    public int getMajCiencias() {
        return majCiencias;
    }

    /**
     * Método toString() resonsável por imprimir tipo de pergunta, pontuação, pergunta, opções e resposta
     * @return Tipo de pergunta, pontuação, pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return "Ciências->" +
                " Pontuação da pergunta: " + atribuiPontuacao() +
                 super.toString();
    }

    /**
     * Método responsável por atribuir pontuação às perguntas de Ciências
     * @return Pontuação Ciências
     */
    @Override
    protected int atribuiPontuacao() {
        setPontuacaoCiencias(getPontuacao()+getMajCiencias());
        return getPontuacaoCiencias();
    }

    /**
     * Método responsável por selecionar as opções que irão aparecer ao jogador, neste caso, dependendo da posição em que a pergunta aparece
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções(String)
     */

    protected String selecionaOpcoes(ArrayList<Pergunta> perguntas) {
        String opcao1;
        String opcao2;
        String opcoesSelecionadas = null;
        String[] opcoes = (getOpcoes()).split("\\|");
        opcao1 = opcoes[0];
        opcao2 = opcoes[1];
        if ((perguntas.indexOf(this)+1) < 3) {
            opcoesSelecionadas = opcao1;
        }
        else if((perguntas.indexOf(this)+1) >= 3){
            opcoesSelecionadas = opcao2;
        }
        return opcoesSelecionadas;
    }
}