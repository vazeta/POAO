import java.io.Serializable;
import java.util.ArrayList;

/**
 * Classe responsável pelas perguntas relacionadas a Ski
 */
public class Ski extends Desporto implements Serializable {
    private int pontuacaoSki;
    private int majSki;
    /**
     * Construtor que inicializa pergunta,opcoes e majoração de ski igual a 2
     * @param pergunta pergunta
     * @param opcoes opções
     * @param resposta resposta
     */
    public Ski(String pergunta, String opcoes, String resposta){
        super(pergunta, opcoes, resposta);
        this.majSki=2;
    }

    /**
     * Método de acesso a pontuação de ski
     * @return pontuação de futebol
     */
    public int getPontuacaoSki() {
        return pontuacaoSki;
    }

    /**
     * Método para alterar pontuação de ski
     * @param pontuacaoSki pontuação de ski
     */
    public void setPontuacaoSki(int pontuacaoSki) {
        this.pontuacaoSki = pontuacaoSki;
    }

    /**
     * Método de acesso a majoração de ski
     * @return majoração de ski
     */
    public int getMajSki() {
        return majSki;
    }

    /**
     * Método toString() resonsável por imprimir tipo de pergunta, pontuação, pergunta, opções e resposta
     * @return Tipo de pergunta, pontuação, pergunta, opções e resposta
     */
    @Override
    public String toString() {
        return "Ski->" + " Pontuaçao da pergunta:" + atribuiPontuacao() + super.toString();
    }

    /**
     * Método responsável por atribuir pontuação às perguntas de ski
     * @return Pontuação de Ski
     */
    @Override
    protected int atribuiPontuacao() {
        setPontuacaoSki(super.atribuiPontuacao()*getMajSki());
        return getPontuacaoSki();
    }

    /**
     * Método responsável por selecionar as opções que irão aparecer ao jogador, neste caso, não são alteradas
     * @param perguntas ArrayList que contém todas as perguntas
     * @return opções(String)
     */
    protected String selecionaOpcoes(ArrayList<Pergunta> perguntas) {
        String opcoesSelecionadas;
        opcoesSelecionadas=getOpcoes();
        return opcoesSelecionadas;
    }
}